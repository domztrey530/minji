public class Cow extends Animal{

   Cow(String name, int age, String breed){
   super(name, age, breed);
   }
   
   public String sound(){
      return "Moooooooo!";
   }
}