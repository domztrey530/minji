
'''
This is a simple linear regression model to predict the CO2 emission from cars
Dataset:
FuelConsumptionTest.csv, which contains model-specific fuel consumption ratings and estimated carbon dioxide emissions
for new light-d+++uty vehicles for retail sale in Canada
'''
import numpy as np
import pandas as pd
import pylab as pl
import pickle
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier

df = pd.read_csv("FuelConsumptionTEST.csv")

# take a look at the dataset
print(df.head())

##number of rows and columns
print(df.shape)

# To create a histogram, we will use pandas hist() method.
df.drop('CO2EMISSIONS', axis=1).hist(bins=30, figsize=(10,10), color = "c", ec = "m", lw=0)
pl.suptitle("Histogram for each numeric input variable")
pl.savefig('emissions_histogram')
print(pl.show())


#use required features
cdf = df[['ENGINESIZE', 'CYLINDERS', 'FUELCONSUMPTION_COMB', 'CO2EMISSIONS']]

#Training Data and Predictor Variable
# Use all data for training (train-test-split not used)
x = cdf.iloc[:, :3]
y = cdf.iloc[:, -1]

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.1, random_state=0)

regressor = LinearRegression()

#Fitting model with trainig data
regressor.fit(x, y)


# Saving model to disk
# Pickle serializes objects so they can be saved to a file, and loaded in a program again later on.
pickle.dump(regressor, open('model.pkl','wb'))


#Loading model to compare the results
model = pickle.load(open('model.pkl','rb'))
test_emmissions = model.predict([[2.6, 8, 10.1]])
print("Test Emmissions: ", test_emmissions)


from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier()

#Train the model using the training sets
knn.fit(x_train, y_train)
KNeighborsClassifier(algorithm='auto', leaf_size=30, metric='minkowski',
                        metric_params=None, n_jobs=None, n_neighbors= 3, p=2, weights='uniform') ####KNN ORIG SIZE = 4

##Evaluate the accuracy of the model for K=4
knn.score(x_test, y_test)
print("Accuracy for K3: ", knn.score(x_test, y_test))

##K=4
knn = KNeighborsClassifier(n_neighbors=4)
knn.fit(x_train, y_train)
knn.score(x_test, y_test)
print("Accuracy for K4: ", knn.score(x_test, y_test))

##K=5
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(x_train, y_train)
knn.score(x_test, y_test)
print("Accuracy for K5: ", knn.score(x_test, y_test))

##K=6
knn = KNeighborsClassifier(n_neighbors=6)
knn.fit(x_train, y_train)
knn.score(x_test, y_test)
print("Accuracy for K6: ", knn.score(x_test, y_test))

##K=7
knn = KNeighborsClassifier(n_neighbors=7)
knn.fit(x_train, y_train)
knn.score(x_test, y_test)
print("Accuracy for K7: ", knn.score(x_test, y_test))


