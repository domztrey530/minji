public class Cat extends Animal{
  
  public Cat(String name, String breed, int age){
   super(name, breed, age);
  }
  
  public Cat(){}
  
  public String sound(){
   return ("Meow!");
  }
  
  public String toString(){
   return super.toString() +"Sound  : "+ sound();
  }
}