public class Dog extends Animal{
  
  public Dog(String name, String breed, int age){
    super(name, breed, age);
  }
  
  public Dog(){}
  
  public String sound(){
   return ("Awrf!");
  }
  
  public String toString(){
	  return super.toString() +"Sound  : "+ sound();
  }
}