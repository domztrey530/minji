public class Dog extends Animal{
  
  public Dog(String name, String breed, int age){
    super(name, breed, age);
  }
  
  public Dog(){}
  
  public String sound(){
   return ("Awrf!");
  }
  
  public String toString(){
	  return super.toString() +"Sound  : "+ sound();
  }
  
//  public static void main(String [] args){
//   Animal a = new Dog("dog", 2,"doggy");
//   System.out.println("The dog is : " + a);
//   System.out.print("The sound of the dog is: "+ a.sound());
//  
//  }
}