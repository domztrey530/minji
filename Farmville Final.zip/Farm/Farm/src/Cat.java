public class Cat extends Animal{
  
  public Cat(String name, String breed, int age){
   super(name, breed, age);
  }
  
  public Cat(){}
  
  public String sound(){
   return ("Meow!");
  }
  
  public String toString(){
   return super.toString() +"Sound  : "+ sound();
  }
  
//  public static void main(String [] args){
//   Animal a = new Cat("cat", 2,"catty");
//   System.out.println("The Cat is : " +a);
//   System.out.print("The sound of the Cat is: "+a.sound());
//   
//  }
  
}