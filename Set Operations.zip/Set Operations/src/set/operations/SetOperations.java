package set.operations;

import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JFrame;


public class SetOperations {
    
    public static void main(String[] args) {
        
        JFrame jf = new MainWindow();
        jf.setTitle("Set Operations");
        jf.setVisible(true);
        
    }
    
}