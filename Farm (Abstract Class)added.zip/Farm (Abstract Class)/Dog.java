public class Dog extends Animal{
  
  public Dog(String name, int age, String breed){
    super(name, age,breed);
  }
  
  public Dog(){}
  
  public String sound(){
   return ("Aww aww");
  }
  
  public String toString(){
   return super.toString() + "\t"+sound()+"\t";
  }
  
  public static void main(String [] args){
   Animal a = new Dog("Catiee", 2,"blackdog");
   System.out.println("The dog is : " + a);
   System.out.print("The sound of the dog is:");
   a.sound();
  }
  
}