public class Cat extends Animal{
  
  public Cat(String name, int age, String breed){
    super(name, age,breed);
  }
  
  public Cat(){}
  
  public String sound(){
   return ("Meow meow");
  }
  
  public String toString(){
   return super.toString() + "\t"+sound()+"\t";
  }
  
  public static void main(String [] args){
   Animal a = new Cat("Catiee", 2,"blackcat");
   System.out.println("The cat is : " + a);
   System.out.print("The sound of the cat is:");
   a.sound();
  }
  
}