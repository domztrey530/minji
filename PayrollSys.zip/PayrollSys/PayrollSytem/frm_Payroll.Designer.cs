﻿namespace PayrollSytem
{
    partial class frm_Payroll
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtppagibig = new System.Windows.Forms.TextBox();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.txtpnetincome = new System.Windows.Forms.TextBox();
            this.Label12 = new System.Windows.Forms.Label();
            this.GroupBox4 = new System.Windows.Forms.GroupBox();
            this.txtpgincome = new System.Windows.Forms.TextBox();
            this.Label11 = new System.Windows.Forms.Label();
            this.txtPholPayDay = new System.Windows.Forms.TextBox();
            this.txtPholPay = new System.Windows.Forms.TextBox();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.txtPregOt = new System.Windows.Forms.TextBox();
            this.txtPRegOtHr = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.txtPrateWage = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.txtPRateperday = new System.Windows.Forms.TextBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.txtPNoDays = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.txtPPayPeriod = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label19 = new System.Windows.Forms.Label();
            this.txtTotaldeduc = new System.Windows.Forms.TextBox();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.txtPAssignCode = new System.Windows.Forms.DomainUpDown();
            this.txtPEmployeeName = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.Label13 = new System.Windows.Forms.Label();
            this.txttrancode = new System.Windows.Forms.TextBox();
            this.TabPage9 = new System.Windows.Forms.TabPage();
            this.txtpsearch = new System.Windows.Forms.TextBox();
            this.dtgParollList = new System.Windows.Forms.DataGridView();
            this.Label15 = new System.Windows.Forms.Label();
            this.TabControl3 = new System.Windows.Forms.TabControl();
            this.TabPage8 = new System.Windows.Forms.TabPage();
            this.PictureBox3 = new System.Windows.Forms.PictureBox();
            this.txtbvale = new System.Windows.Forms.TextBox();
            this.Button2 = new System.Windows.Forms.Button();
            this.btnPsave = new System.Windows.Forms.Button();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.GroupBox7 = new System.Windows.Forms.GroupBox();
            this.txtpremarks = new System.Windows.Forms.RichTextBox();
            this.GroupBox5 = new System.Windows.Forms.GroupBox();
            this.GroupBox6 = new System.Windows.Forms.GroupBox();
            this.Label18 = new System.Windows.Forms.Label();
            this.txtpdeducttot = new System.Windows.Forms.TextBox();
            this.Label17 = new System.Windows.Forms.Label();
            this.txtpdeduct4 = new System.Windows.Forms.TextBox();
            this.txtpdeductname4 = new System.Windows.Forms.TextBox();
            this.txtpdeduct3 = new System.Windows.Forms.TextBox();
            this.txtpdeductname3 = new System.Windows.Forms.TextBox();
            this.txtpdeduct2 = new System.Windows.Forms.TextBox();
            this.txtpdeductname2 = new System.Windows.Forms.TextBox();
            this.txtpdeduct1 = new System.Windows.Forms.TextBox();
            this.txtpdeductname1 = new System.Windows.Forms.TextBox();
            this.txtpcadvance = new System.Windows.Forms.TextBox();
            this.txtpphic = new System.Windows.Forms.TextBox();
            this.Label16 = new System.Windows.Forms.Label();
            this.Label14 = new System.Windows.Forms.Label();
            this.GroupBox3.SuspendLayout();
            this.GroupBox4.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.TabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgParollList)).BeginInit();
            this.TabControl3.SuspendLayout();
            this.TabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).BeginInit();
            this.GroupBox2.SuspendLayout();
            this.GroupBox7.SuspendLayout();
            this.GroupBox5.SuspendLayout();
            this.GroupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtppagibig
            // 
            this.txtppagibig.Location = new System.Drawing.Point(107, 89);
            this.txtppagibig.Name = "txtppagibig";
            this.txtppagibig.Size = new System.Drawing.Size(133, 20);
            this.txtppagibig.TabIndex = 8;
            this.txtppagibig.Text = "0";
            this.txtppagibig.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtppagibig.TextChanged += new System.EventHandler(this.txtppagibig_TextChanged);
            // 
            // GroupBox3
            // 
            this.GroupBox3.Controls.Add(this.txtpnetincome);
            this.GroupBox3.Controls.Add(this.Label12);
            this.GroupBox3.Controls.Add(this.GroupBox4);
            this.GroupBox3.Controls.Add(this.txtPrateWage);
            this.GroupBox3.Controls.Add(this.Label9);
            this.GroupBox3.Controls.Add(this.txtPRateperday);
            this.GroupBox3.Controls.Add(this.Label10);
            this.GroupBox3.Controls.Add(this.txtPNoDays);
            this.GroupBox3.Controls.Add(this.Label5);
            this.GroupBox3.Controls.Add(this.txtPPayPeriod);
            this.GroupBox3.Controls.Add(this.Label6);
            this.GroupBox3.Location = new System.Drawing.Point(10, 19);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(493, 255);
            this.GroupBox3.TabIndex = 2;
            this.GroupBox3.TabStop = false;
            this.GroupBox3.Text = "Income";
            // 
            // txtpnetincome
            // 
            this.txtpnetincome.BackColor = System.Drawing.Color.Cyan;
            this.txtpnetincome.Enabled = false;
            this.txtpnetincome.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpnetincome.Location = new System.Drawing.Point(110, 178);
            this.txtpnetincome.Name = "txtpnetincome";
            this.txtpnetincome.Size = new System.Drawing.Size(367, 53);
            this.txtpnetincome.TabIndex = 21;
            this.txtpnetincome.Text = "0";
            this.txtpnetincome.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Location = new System.Drawing.Point(39, 181);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(65, 13);
            this.Label12.TabIndex = 21;
            this.Label12.Text = "Net Income:";
            // 
            // GroupBox4
            // 
            this.GroupBox4.Controls.Add(this.txtpgincome);
            this.GroupBox4.Controls.Add(this.Label11);
            this.GroupBox4.Controls.Add(this.txtPholPayDay);
            this.GroupBox4.Controls.Add(this.txtPholPay);
            this.GroupBox4.Controls.Add(this.Label7);
            this.GroupBox4.Controls.Add(this.Label3);
            this.GroupBox4.Controls.Add(this.txtPregOt);
            this.GroupBox4.Controls.Add(this.txtPRegOtHr);
            this.GroupBox4.Controls.Add(this.Label8);
            this.GroupBox4.Controls.Add(this.Label4);
            this.GroupBox4.Location = new System.Drawing.Point(8, 73);
            this.GroupBox4.Name = "GroupBox4";
            this.GroupBox4.Size = new System.Drawing.Size(480, 99);
            this.GroupBox4.TabIndex = 19;
            this.GroupBox4.TabStop = false;
            this.GroupBox4.Text = "OT hr/day:";
            // 
            // txtpgincome
            // 
            this.txtpgincome.Enabled = false;
            this.txtpgincome.Location = new System.Drawing.Point(336, 67);
            this.txtpgincome.Name = "txtpgincome";
            this.txtpgincome.Size = new System.Drawing.Size(133, 20);
            this.txtpgincome.TabIndex = 20;
            this.txtpgincome.Text = "0";
            this.txtpgincome.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Location = new System.Drawing.Point(241, 70);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(75, 13);
            this.Label11.TabIndex = 19;
            this.Label11.Text = "Gross Income:";
            // 
            // txtPholPayDay
            // 
            this.txtPholPayDay.Location = new System.Drawing.Point(104, 46);
            this.txtPholPayDay.Name = "txtPholPayDay";
            this.txtPholPayDay.Size = new System.Drawing.Size(133, 20);
            this.txtPholPayDay.TabIndex = 4;
            this.txtPholPayDay.TextChanged += new System.EventHandler(this.txtPholPayDay_TextChanged);
            // 
            // txtPholPay
            // 
            this.txtPholPay.Enabled = false;
            this.txtPholPay.Location = new System.Drawing.Point(336, 41);
            this.txtPholPay.Name = "txtPholPay";
            this.txtPholPay.Size = new System.Drawing.Size(133, 20);
            this.txtPholPay.TabIndex = 18;
            this.txtPholPay.Text = "0";
            this.txtPholPay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(269, 44);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(49, 13);
            this.Label7.TabIndex = 17;
            this.Label7.Text = "Hol. pay:";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(20, 23);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(66, 13);
            this.Label3.TabIndex = 3;
            this.Label3.Text = "Reg. OT[hr]:";
            // 
            // txtPregOt
            // 
            this.txtPregOt.Enabled = false;
            this.txtPregOt.Location = new System.Drawing.Point(336, 15);
            this.txtPregOt.Name = "txtPregOt";
            this.txtPregOt.Size = new System.Drawing.Size(133, 20);
            this.txtPregOt.TabIndex = 16;
            this.txtPregOt.Text = "0";
            this.txtPregOt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtPRegOtHr
            // 
            this.txtPRegOtHr.Location = new System.Drawing.Point(104, 20);
            this.txtPRegOtHr.Name = "txtPRegOtHr";
            this.txtPRegOtHr.Size = new System.Drawing.Size(133, 20);
            this.txtPRegOtHr.TabIndex = 3;
            this.txtPRegOtHr.TextChanged += new System.EventHandler(this.txtPRegOtHr_TextChanged);
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(267, 18);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(51, 13);
            this.Label8.TabIndex = 15;
            this.Label8.Text = "Reg. OT:";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(11, 49);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(75, 13);
            this.Label4.TabIndex = 5;
            this.Label4.Text = "Hol. pay [day]:";
            // 
            // txtPrateWage
            // 
            this.txtPrateWage.Enabled = false;
            this.txtPrateWage.Location = new System.Drawing.Point(342, 45);
            this.txtPrateWage.Name = "txtPrateWage";
            this.txtPrateWage.Size = new System.Drawing.Size(133, 20);
            this.txtPrateWage.TabIndex = 14;
            this.txtPrateWage.Text = "0";
            this.txtPrateWage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(261, 47);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(65, 13);
            this.Label9.TabIndex = 13;
            this.Label9.Text = "Rate Wage:";
            // 
            // txtPRateperday
            // 
            this.txtPRateperday.Enabled = false;
            this.txtPRateperday.Location = new System.Drawing.Point(342, 19);
            this.txtPRateperday.Name = "txtPRateperday";
            this.txtPRateperday.Size = new System.Drawing.Size(133, 20);
            this.txtPRateperday.TabIndex = 12;
            this.txtPRateperday.Text = "0";
            this.txtPRateperday.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Location = new System.Drawing.Point(255, 22);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(71, 13);
            this.Label10.TabIndex = 11;
            this.Label10.Text = "Rate per day:";
            // 
            // txtPNoDays
            // 
            this.txtPNoDays.Location = new System.Drawing.Point(110, 45);
            this.txtPNoDays.Name = "txtPNoDays";
            this.txtPNoDays.Size = new System.Drawing.Size(133, 20);
            this.txtPNoDays.TabIndex = 2;
            this.txtPNoDays.TextChanged += new System.EventHandler(this.txtPNoDays_TextChanged);
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(9, 46);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(66, 13);
            this.Label5.TabIndex = 9;
            this.Label5.Text = "No. of Days:";
            // 
            // txtPPayPeriod
            // 
            this.txtPPayPeriod.Enabled = false;
            this.txtPPayPeriod.Location = new System.Drawing.Point(110, 19);
            this.txtPPayPeriod.Name = "txtPPayPeriod";
            this.txtPPayPeriod.Size = new System.Drawing.Size(133, 20);
            this.txtPPayPeriod.TabIndex = 8;
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(9, 20);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(73, 13);
            this.Label6.TabIndex = 7;
            this.Label6.Text = "Pay Method  :";
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.Location = new System.Drawing.Point(599, 61);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(44, 13);
            this.Label19.TabIndex = 1;
            this.Label19.Text = "Search:";
            // 
            // txtTotaldeduc
            // 
            this.txtTotaldeduc.Location = new System.Drawing.Point(664, 71);
            this.txtTotaldeduc.Name = "txtTotaldeduc";
            this.txtTotaldeduc.Size = new System.Drawing.Size(100, 20);
            this.txtTotaldeduc.TabIndex = 31;
            this.txtTotaldeduc.Visible = false;
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.txtPAssignCode);
            this.GroupBox1.Controls.Add(this.txtPEmployeeName);
            this.GroupBox1.Controls.Add(this.Label2);
            this.GroupBox1.Controls.Add(this.Label1);
            this.GroupBox1.Location = new System.Drawing.Point(15, 19);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(498, 81);
            this.GroupBox1.TabIndex = 0;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Employee Details";
            // 
            // txtPAssignCode
            // 
            this.txtPAssignCode.Location = new System.Drawing.Point(100, 21);
            this.txtPAssignCode.Name = "txtPAssignCode";
            this.txtPAssignCode.Size = new System.Drawing.Size(230, 20);
            this.txtPAssignCode.TabIndex = 1;
            this.txtPAssignCode.TextChanged += new System.EventHandler(this.txtPAssignCode_TextChanged);
            // 
            // txtPEmployeeName
            // 
            this.txtPEmployeeName.Enabled = false;
            this.txtPEmployeeName.Location = new System.Drawing.Point(99, 47);
            this.txtPEmployeeName.Name = "txtPEmployeeName";
            this.txtPEmployeeName.Size = new System.Drawing.Size(325, 20);
            this.txtPEmployeeName.TabIndex = 2;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(25, 24);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(69, 13);
            this.Label2.TabIndex = 1;
            this.Label2.Text = "Assign Code:";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(7, 50);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(87, 13);
            this.Label1.TabIndex = 0;
            this.Label1.Text = "Employee Name:";
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Location = new System.Drawing.Point(571, 66);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(62, 13);
            this.Label13.TabIndex = 28;
            this.Label13.Text = "Bread Vale:";
            // 
            // txttrancode
            // 
            this.txttrancode.Location = new System.Drawing.Point(569, 45);
            this.txttrancode.Name = "txttrancode";
            this.txttrancode.Size = new System.Drawing.Size(100, 20);
            this.txttrancode.TabIndex = 3;
            // 
            // TabPage9
            // 
            this.TabPage9.Controls.Add(this.txtpsearch);
            this.TabPage9.Controls.Add(this.Label19);
            this.TabPage9.Controls.Add(this.dtgParollList);
            this.TabPage9.Location = new System.Drawing.Point(4, 22);
            this.TabPage9.Name = "TabPage9";
            this.TabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage9.Size = new System.Drawing.Size(849, 497);
            this.TabPage9.TabIndex = 1;
            this.TabPage9.Text = "List";
            this.TabPage9.UseVisualStyleBackColor = true;
            // 
            // txtpsearch
            // 
            this.txtpsearch.Location = new System.Drawing.Point(649, 58);
            this.txtpsearch.Name = "txtpsearch";
            this.txtpsearch.Size = new System.Drawing.Size(193, 20);
            this.txtpsearch.TabIndex = 2;
            this.txtpsearch.TextChanged += new System.EventHandler(this.txtpsearch_TextChanged);
            // 
            // dtgParollList
            // 
            this.dtgParollList.AllowUserToAddRows = false;
            this.dtgParollList.AllowUserToDeleteRows = false;
            this.dtgParollList.AllowUserToResizeColumns = false;
            this.dtgParollList.AllowUserToResizeRows = false;
            this.dtgParollList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtgParollList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgParollList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtgParollList.Location = new System.Drawing.Point(4, 84);
            this.dtgParollList.Name = "dtgParollList";
            this.dtgParollList.RowHeadersVisible = false;
            this.dtgParollList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgParollList.Size = new System.Drawing.Size(838, 373);
            this.dtgParollList.TabIndex = 0;
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.Location = new System.Drawing.Point(14, 92);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(34, 13);
            this.Label15.TabIndex = 24;
            this.Label15.Text = "SSS :";
            // 
            // TabControl3
            // 
            this.TabControl3.Controls.Add(this.TabPage8);
            this.TabControl3.Controls.Add(this.TabPage9);
            this.TabControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TabControl3.Location = new System.Drawing.Point(0, 0);
            this.TabControl3.Name = "TabControl3";
            this.TabControl3.SelectedIndex = 0;
            this.TabControl3.Size = new System.Drawing.Size(857, 523);
            this.TabControl3.TabIndex = 2;
            // 
            // TabPage8
            // 
            this.TabPage8.Controls.Add(this.PictureBox3);
            this.TabPage8.Controls.Add(this.txtbvale);
            this.TabPage8.Controls.Add(this.Button2);
            this.TabPage8.Controls.Add(this.btnPsave);
            this.TabPage8.Controls.Add(this.GroupBox2);
            this.TabPage8.Controls.Add(this.txtTotaldeduc);
            this.TabPage8.Controls.Add(this.GroupBox1);
            this.TabPage8.Controls.Add(this.Label13);
            this.TabPage8.Controls.Add(this.txttrancode);
            this.TabPage8.Location = new System.Drawing.Point(4, 22);
            this.TabPage8.Name = "TabPage8";
            this.TabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage8.Size = new System.Drawing.Size(849, 497);
            this.TabPage8.TabIndex = 0;
            this.TabPage8.Text = "Create Payroll";
            this.TabPage8.UseVisualStyleBackColor = true;
            // 
            // PictureBox3
            // 
            this.PictureBox3.Location = new System.Drawing.Point(536, 28);
            this.PictureBox3.Name = "PictureBox3";
            this.PictureBox3.Size = new System.Drawing.Size(288, 71);
            this.PictureBox3.TabIndex = 32;
            this.PictureBox3.TabStop = false;
            // 
            // txtbvale
            // 
            this.txtbvale.Location = new System.Drawing.Point(664, 64);
            this.txtbvale.Name = "txtbvale";
            this.txtbvale.Size = new System.Drawing.Size(133, 20);
            this.txtbvale.TabIndex = 6;
            // 
            // Button2
            // 
            this.Button2.Location = new System.Drawing.Point(692, 450);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(118, 29);
            this.Button2.TabIndex = 19;
            this.Button2.Text = "NEW";
            this.Button2.UseVisualStyleBackColor = true;
            this.Button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // btnPsave
            // 
            this.btnPsave.Location = new System.Drawing.Point(555, 450);
            this.btnPsave.Name = "btnPsave";
            this.btnPsave.Size = new System.Drawing.Size(131, 29);
            this.btnPsave.TabIndex = 18;
            this.btnPsave.Text = "SAVE";
            this.btnPsave.UseVisualStyleBackColor = true;
            this.btnPsave.Click += new System.EventHandler(this.btnPsave_Click);
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.GroupBox7);
            this.GroupBox2.Controls.Add(this.GroupBox5);
            this.GroupBox2.Controls.Add(this.GroupBox3);
            this.GroupBox2.Location = new System.Drawing.Point(15, 105);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(805, 386);
            this.GroupBox2.TabIndex = 1;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Payroll Details";
            // 
            // GroupBox7
            // 
            this.GroupBox7.Controls.Add(this.txtpremarks);
            this.GroupBox7.Location = new System.Drawing.Point(7, 283);
            this.GroupBox7.Name = "GroupBox7";
            this.GroupBox7.Size = new System.Drawing.Size(491, 88);
            this.GroupBox7.TabIndex = 4;
            this.GroupBox7.TabStop = false;
            this.GroupBox7.Text = "Remarks:";
            // 
            // txtpremarks
            // 
            this.txtpremarks.Location = new System.Drawing.Point(9, 20);
            this.txtpremarks.Name = "txtpremarks";
            this.txtpremarks.Size = new System.Drawing.Size(474, 53);
            this.txtpremarks.TabIndex = 17;
            this.txtpremarks.Text = "";
            // 
            // GroupBox5
            // 
            this.GroupBox5.Controls.Add(this.GroupBox6);
            this.GroupBox5.Controls.Add(this.txtpcadvance);
            this.GroupBox5.Controls.Add(this.txtpphic);
            this.GroupBox5.Controls.Add(this.Label16);
            this.GroupBox5.Controls.Add(this.Label14);
            this.GroupBox5.Controls.Add(this.txtppagibig);
            this.GroupBox5.Controls.Add(this.Label15);
            this.GroupBox5.Location = new System.Drawing.Point(509, 18);
            this.GroupBox5.Name = "GroupBox5";
            this.GroupBox5.Size = new System.Drawing.Size(290, 314);
            this.GroupBox5.TabIndex = 3;
            this.GroupBox5.TabStop = false;
            this.GroupBox5.Text = "Deductions:";
            // 
            // GroupBox6
            // 
            this.GroupBox6.Controls.Add(this.Label18);
            this.GroupBox6.Controls.Add(this.txtpdeducttot);
            this.GroupBox6.Controls.Add(this.Label17);
            this.GroupBox6.Controls.Add(this.txtpdeduct4);
            this.GroupBox6.Controls.Add(this.txtpdeductname4);
            this.GroupBox6.Controls.Add(this.txtpdeduct3);
            this.GroupBox6.Controls.Add(this.txtpdeductname3);
            this.GroupBox6.Controls.Add(this.txtpdeduct2);
            this.GroupBox6.Controls.Add(this.txtpdeductname2);
            this.GroupBox6.Controls.Add(this.txtpdeduct1);
            this.GroupBox6.Controls.Add(this.txtpdeductname1);
            this.GroupBox6.Location = new System.Drawing.Point(6, 125);
            this.GroupBox6.Name = "GroupBox6";
            this.GroupBox6.Size = new System.Drawing.Size(280, 182);
            this.GroupBox6.TabIndex = 30;
            this.GroupBox6.TabStop = false;
            this.GroupBox6.Text = "Other Deductions:";
            // 
            // Label18
            // 
            this.Label18.AutoSize = true;
            this.Label18.Location = new System.Drawing.Point(11, 16);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(64, 13);
            this.Label18.TabIndex = 31;
            this.Label18.Text = "Deductions:";
            // 
            // txtpdeducttot
            // 
            this.txtpdeducttot.Enabled = false;
            this.txtpdeducttot.Location = new System.Drawing.Point(141, 137);
            this.txtpdeducttot.Name = "txtpdeducttot";
            this.txtpdeducttot.Size = new System.Drawing.Size(133, 20);
            this.txtpdeducttot.TabIndex = 23;
            this.txtpdeducttot.Text = "0";
            this.txtpdeducttot.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.Location = new System.Drawing.Point(105, 140);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(34, 13);
            this.Label17.TabIndex = 22;
            this.Label17.Text = "Total:";
            // 
            // txtpdeduct4
            // 
            this.txtpdeduct4.Location = new System.Drawing.Point(145, 111);
            this.txtpdeduct4.Name = "txtpdeduct4";
            this.txtpdeduct4.Size = new System.Drawing.Size(133, 20);
            this.txtpdeduct4.TabIndex = 16;
            this.txtpdeduct4.Text = "0";
            this.txtpdeduct4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpdeduct4.TextChanged += new System.EventHandler(this.txtpdeduct4_TextChanged);
            // 
            // txtpdeductname4
            // 
            this.txtpdeductname4.Location = new System.Drawing.Point(6, 111);
            this.txtpdeductname4.Name = "txtpdeductname4";
            this.txtpdeductname4.Size = new System.Drawing.Size(133, 20);
            this.txtpdeductname4.TabIndex = 15;
            // 
            // txtpdeduct3
            // 
            this.txtpdeduct3.Location = new System.Drawing.Point(145, 85);
            this.txtpdeduct3.Name = "txtpdeduct3";
            this.txtpdeduct3.Size = new System.Drawing.Size(133, 20);
            this.txtpdeduct3.TabIndex = 14;
            this.txtpdeduct3.Text = "0";
            this.txtpdeduct3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpdeduct3.TextChanged += new System.EventHandler(this.txtpdeduct3_TextChanged);
            // 
            // txtpdeductname3
            // 
            this.txtpdeductname3.Location = new System.Drawing.Point(6, 85);
            this.txtpdeductname3.Name = "txtpdeductname3";
            this.txtpdeductname3.Size = new System.Drawing.Size(133, 20);
            this.txtpdeductname3.TabIndex = 13;
            // 
            // txtpdeduct2
            // 
            this.txtpdeduct2.Location = new System.Drawing.Point(145, 59);
            this.txtpdeduct2.Name = "txtpdeduct2";
            this.txtpdeduct2.Size = new System.Drawing.Size(133, 20);
            this.txtpdeduct2.TabIndex = 12;
            this.txtpdeduct2.Text = "0";
            this.txtpdeduct2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpdeduct2.TextChanged += new System.EventHandler(this.txtpdeduct2_TextChanged);
            // 
            // txtpdeductname2
            // 
            this.txtpdeductname2.Location = new System.Drawing.Point(6, 59);
            this.txtpdeductname2.Name = "txtpdeductname2";
            this.txtpdeductname2.Size = new System.Drawing.Size(133, 20);
            this.txtpdeductname2.TabIndex = 11;
            // 
            // txtpdeduct1
            // 
            this.txtpdeduct1.Location = new System.Drawing.Point(145, 33);
            this.txtpdeduct1.Name = "txtpdeduct1";
            this.txtpdeduct1.Size = new System.Drawing.Size(133, 20);
            this.txtpdeduct1.TabIndex = 10;
            this.txtpdeduct1.Text = "0";
            this.txtpdeduct1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpdeduct1.TextChanged += new System.EventHandler(this.txtpdeduct1_TextChanged);
            // 
            // txtpdeductname1
            // 
            this.txtpdeductname1.Location = new System.Drawing.Point(6, 33);
            this.txtpdeductname1.Name = "txtpdeductname1";
            this.txtpdeductname1.Size = new System.Drawing.Size(133, 20);
            this.txtpdeductname1.TabIndex = 9;
            // 
            // txtpcadvance
            // 
            this.txtpcadvance.Location = new System.Drawing.Point(107, 35);
            this.txtpcadvance.Name = "txtpcadvance";
            this.txtpcadvance.Size = new System.Drawing.Size(133, 20);
            this.txtpcadvance.TabIndex = 5;
            this.txtpcadvance.Text = "0";
            this.txtpcadvance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpcadvance.TextChanged += new System.EventHandler(this.txtpcadvance_TextChanged);
            // 
            // txtpphic
            // 
            this.txtpphic.Location = new System.Drawing.Point(107, 63);
            this.txtpphic.Name = "txtpphic";
            this.txtpphic.Size = new System.Drawing.Size(133, 20);
            this.txtpphic.TabIndex = 7;
            this.txtpphic.Text = "0";
            this.txtpphic.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpphic.TextChanged += new System.EventHandler(this.txtpphic_TextChanged);
            // 
            // Label16
            // 
            this.Label16.AutoSize = true;
            this.Label16.Location = new System.Drawing.Point(14, 65);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(35, 13);
            this.Label16.TabIndex = 22;
            this.Label16.Text = "PHIC:";
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Location = new System.Drawing.Point(14, 35);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(80, 13);
            this.Label14.TabIndex = 26;
            this.Label14.Text = "Cash Advance:";
            // 
            // frm_Payroll
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 523);
            this.Controls.Add(this.TabControl3);
            this.Name = "frm_Payroll";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Payroll";
            this.Load += new System.EventHandler(this.frm_Payroll_Load);
            this.GroupBox3.ResumeLayout(false);
            this.GroupBox3.PerformLayout();
            this.GroupBox4.ResumeLayout(false);
            this.GroupBox4.PerformLayout();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.TabPage9.ResumeLayout(false);
            this.TabPage9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgParollList)).EndInit();
            this.TabControl3.ResumeLayout(false);
            this.TabPage8.ResumeLayout(false);
            this.TabPage8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).EndInit();
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox7.ResumeLayout(false);
            this.GroupBox5.ResumeLayout(false);
            this.GroupBox5.PerformLayout();
            this.GroupBox6.ResumeLayout(false);
            this.GroupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.TextBox txtppagibig;
        internal System.Windows.Forms.GroupBox GroupBox3;
        internal System.Windows.Forms.TextBox txtpnetincome;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.GroupBox GroupBox4;
        internal System.Windows.Forms.TextBox txtpgincome;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.TextBox txtPholPayDay;
        internal System.Windows.Forms.TextBox txtPholPay;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox txtPregOt;
        internal System.Windows.Forms.TextBox txtPRegOtHr;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TextBox txtPrateWage;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.TextBox txtPRateperday;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.TextBox txtPNoDays;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox txtPPayPeriod;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.TextBox txtTotaldeduc;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.DomainUpDown txtPAssignCode;
        internal System.Windows.Forms.TextBox txtPEmployeeName;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.TextBox txttrancode;
        internal System.Windows.Forms.TabPage TabPage9;
        internal System.Windows.Forms.TextBox txtpsearch;
        internal System.Windows.Forms.DataGridView dtgParollList;
        internal System.Windows.Forms.Label Label15;
        internal System.Windows.Forms.TabControl TabControl3;
        internal System.Windows.Forms.TabPage TabPage8;
        internal System.Windows.Forms.PictureBox PictureBox3;
        internal System.Windows.Forms.TextBox txtbvale;
        internal System.Windows.Forms.Button Button2;
        internal System.Windows.Forms.Button btnPsave;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.GroupBox GroupBox7;
        internal System.Windows.Forms.RichTextBox txtpremarks;
        internal System.Windows.Forms.GroupBox GroupBox5;
        internal System.Windows.Forms.GroupBox GroupBox6;
        internal System.Windows.Forms.Label Label18;
        internal System.Windows.Forms.TextBox txtpdeducttot;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.TextBox txtpdeduct4;
        internal System.Windows.Forms.TextBox txtpdeductname4;
        internal System.Windows.Forms.TextBox txtpdeduct3;
        internal System.Windows.Forms.TextBox txtpdeductname3;
        internal System.Windows.Forms.TextBox txtpdeduct2;
        internal System.Windows.Forms.TextBox txtpdeductname2;
        internal System.Windows.Forms.TextBox txtpdeduct1;
        internal System.Windows.Forms.TextBox txtpdeductname1;
        internal System.Windows.Forms.TextBox txtpcadvance;
        internal System.Windows.Forms.TextBox txtpphic;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.Label Label14;
    }
}