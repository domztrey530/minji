# Set-Operations-Simulator
A desktop application that simulates set operations: union, intersection, difference and complement with a nice GUI.
