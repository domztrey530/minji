/*
   Dela Rita, Dominic Nicko B.
   BSIT 3-B
*/
public class MySetMain 
{
    public static void main(String [] args)
    {
    MySet setA = new MySet();
    MySet setB = new MySet();
    setA.add(6);
    setA.add(1);
    setA.add(3);
    setA.add(5);
    setA.add(5);
    
    setB.add(1);
    setB.add(5);
    setB.add(2);
    System.out.println("setA contains:" + setA);
    System.out.println("setB contain:" + setB);
    System.out.println("setA.union(setB):" + setA.union(setB));
    System.out.println("set A intersection set B: " + setA.intersection(setB));
    System.out.println("set A - B: " + setA.differenceA(setB));
    System.out.println("set B - A: " + setA.differenceB(setB));
    System.out.println("set B subset of set A?: " + setA.isSubset(setB));
   }
}